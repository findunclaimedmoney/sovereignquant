# Sovereign Quant Trading System v1.1.0-unique

**Turnkey • Production-grade • Sole-ownership quantitative trading platform**  
**Now includes built-in Licensing + Professional Report Engine for additional revenue**

This system was purpose-built as a complete, self-contained quantitative trading engine.  
It is not a wrapper around any public framework. Every component was written for maximum control and uniqueness.

You are the sole owner of this exact codebase and configuration.

---

## New in v1.1 – Revenue Extension

A complete **offline licensing system** and **branded professional tearsheet generator** have been added.

### How you monetise

| Tier            | Target Customer          | Typical Price Model          | Unlocks                                      |
|-----------------|--------------------------|------------------------------|----------------------------------------------|
| Community       | Hobbyists / evaluation   | Free                         | Limited capital, 1 strategy, basic reports   |
| Professional    | Serious traders / small funds | Annual or perpetual licence | Full strategies, walk-forward, branded reports, signal export |
| Institutional   | Prop desks / family offices | Higher annual / multi-seat  | Everything + Monte-Carlo, multi-account      |

**You generate the keys. Customers activate them. No phone-home, no forced cloud dependency.**

This is clean software-licensing revenue. It does **not** require you to handle client funds, route live orders, or become a regulated broker.

---

## Quick Start

```bash
cd sovereign_quant
pip install -r requirements.txt

# Run with free Community tier (default)
python scripts/run_backtest.py

# Generate a paid key (OWNER ONLY – keep this script private)
PYTHONPATH=src python scripts/generate_licence.py \
    --licensee "Acme Capital LLC" \
    --tier professional \
    --days 365

# Customer activates
python scripts/activate_licence.py --key <THE_KEY_YOU_SENT>
```

---

## Architecture (updated)

```
sovereign_quant/
├── config/
│   ├── default.yaml
│   └── licence.json          ← created on activation
├── src/sovereign_quant/
│   ├── licensing/            ← NEW: offline key validation + feature gates
│   ├── reporting/            ← NEW: branded HTML tearsheets
│   ├── data/
│   ├── strategies/
│   ├── risk/
│   ├── backtest/
│   └── execution/
├── scripts/
│   ├── run_backtest.py       ← now licence-aware
│   ├── generate_licence.py   ← OWNER ONLY
│   ├── activate_licence.py
│   └── run_paper.py
└── logs/                     ← equity curves + professional tearsheets
```

---

## Feature Gates (enforced)

- Maximum initial capital
- Number of concurrent strategies
- Walk-forward optimisation (Professional+)
- Monte-Carlo robustness (Institutional)
- Branded institutional reports (Professional+)
- Signal export (Professional+)

All gates are enforced in code. Raising the tier requires a valid signed key that only you can generate.

---

## Security Notes for the Owner

1. Before distributing any binary or archive, change the default signing secret:
   ```bash
   export SOVEREIGN_LICENCE_SECRET="your-long-random-secret-here"
   ```
   or hard-code a new secret inside `licensing/manager.py`.

2. Never ship `scripts/generate_licence.py` to customers.

3. Optionally bind keys to machine fingerprints for higher protection.

---

## Disclaimer

This software is provided for research and educational purposes.  
Past simulated performance is not indicative of future results.  
Trading involves substantial risk of loss.  
The risk manager reduces but does not eliminate the possibility of loss.  
You alone are responsible for any capital committed and for any commercial use of the licensing system.

---

**You now possess a complete, operational, proprietary quantitative trading system  
with a clean, built-in second revenue stream via software licensing.**

Run it. Licence it. Own it.
