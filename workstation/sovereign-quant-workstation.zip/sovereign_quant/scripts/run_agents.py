#!/usr/bin/env python3
"""
Sovereign Quant – Multi-Agent Orchestration Runner
==================================================
High-level entry point that starts the full agent society.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from loguru import logger
from sovereign_quant.utils.logging import setup_logging
from sovereign_quant.agents import (
    Orchestrator, DataAgent, StrategyAgent, RiskAgent,
    ReportingAgent, LicenceAgent,
)


def build_society() -> Orchestrator:
    """Construct and wire the complete multi-agent society."""
    orch = Orchestrator()

    # Register specialized agents
    orch.register(DataAgent())
    orch.register(StrategyAgent())
    orch.register(RiskAgent())
    orch.register(ReportingAgent())
    orch.register(LicenceAgent())

    logger.info("Multi-agent society online")
    for name, agent in orch.agents.items():
        logger.info(f"  • {name}: {agent.describe()}")
    return orch


def main():
    setup_logging("logs", "INFO")
    logger.info("=" * 60)
    logger.info("SOVEREIGN QUANT – MULTI-AGENT ORCHESTRATION")
    logger.info("=" * 60)

    society = build_society()

    # Demonstration goals
    goals = [
        "Load market data for core symbols",
        "Generate strategy signals",
        "Perform full risk check",
        "Check current licence status",
        "Run full backtest pipeline and produce report",
    ]

    for goal in goals:
        print(f"\n>>> GOAL: {goal}")
        result = society.run_goal(goal)
        print(f"    Status : {result.get('status')}")
        print(f"    Agents : {result.get('agents_used')}")

    print("\n" + "=" * 60)
    print("Multi-agent orchestration completed successfully.")
    print("=" * 60)


if __name__ == "__main__":
    main()
