#!/usr/bin/env python3
"""
Sovereign Quant – Paper Trading Launcher
========================================
Connects to exchange sandbox / demo and runs a continuous paper loop.
Requires API keys in .env for authenticated endpoints (balance, orders).
Public data works without keys.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import yaml
from loguru import logger
from dotenv import load_dotenv

from sovereign_quant.utils.logging import setup_logging
from sovereign_quant.execution.broker import Broker


def main():
    load_dotenv(ROOT / ".env")
    with open(ROOT / "config" / "default.yaml") as f:
        cfg = yaml.safe_load(f)

    setup_logging(cfg["system"]["log_dir"], cfg["system"]["log_level"])
    logger.info("SOVEREIGN QUANT PAPER TRADING MODE")
    logger.warning("SANDBOX FORCED – real funds are never touched unless you edit broker.py")

    broker = Broker(
        exchange_id=cfg["execution"]["exchange"],
        sandbox=cfg["execution"]["sandbox"],
    )

    logger.info("Fetching balance (may be zero on pure public sandbox)...")
    try:
        bal = broker.fetch_balance()
        logger.info(f"Balance snapshot: { {k: v for k, v in bal.get('total', {}).items() if v} }")
    except Exception as e:
        logger.warning(f"Balance fetch failed (expected without keys): {e}")

    logger.info("Paper loop ready. In production this would poll signals every N minutes.")
    logger.info("Edit this script to wire live signal generation + risk checks.")
    logger.info("Exiting cleanly after connection test.")


if __name__ == "__main__":
    main()
