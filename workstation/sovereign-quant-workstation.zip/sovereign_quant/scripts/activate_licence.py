#!/usr/bin/env python3
"""
Activate a Sovereign Quant licence key on this machine.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from sovereign_quant.licensing import LicenceManager


def main():
    parser = argparse.ArgumentParser(description="Activate Sovereign Quant licence")
    parser.add_argument("--key", required=True, help="Licence key string received from vendor")
    args = parser.parse_args()

    mgr = LicenceManager(licence_file=ROOT / "config" / "licence.json")
    try:
        info = mgr.activate(args.key)
        print("\nLicence activated successfully")
        print(f"  Tier     : {info.tier.value.upper()}")
        print(f"  Licensee : {info.licensee}")
        print(f"  Issued   : {info.issued}")
        print(f"  Expires  : {info.expires or 'Perpetual'}")
        print("\nFeatures unlocked:")
        for k, v in info.features.items():
            print(f"  {k}: {v}")
    except Exception as e:
        print(f"Activation failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
