#!/usr/bin/env python3
"""
Sovereign Quant – One-command backtest runner
=============================================
Now includes licence-aware feature gating and professional tearsheet generation.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import argparse
import yaml
from loguru import logger

from sovereign_quant.utils.logging import setup_logging
from sovereign_quant.data.loader import DataLoader
from sovereign_quant.strategies.pairs import PairsStrategy
from sovereign_quant.strategies.momentum import MomentumStrategy
from sovereign_quant.strategies.mean_reversion import MeanReversionStrategy
from sovereign_quant.backtest.engine import BacktestEngine
from sovereign_quant.risk.manager import RiskLimits
from sovereign_quant.licensing import LicenceManager
from sovereign_quant.reporting import TearsheetGenerator


def main():
    parser = argparse.ArgumentParser(description="Sovereign Quant Backtest")
    parser.add_argument("--config", default=str(ROOT / "config" / "default.yaml"))
    parser.add_argument("--start", default=None)
    parser.add_argument("--end", default=None)
    parser.add_argument("--cash", type=float, default=None)
    args = parser.parse_args()

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    setup_logging(cfg["system"]["log_dir"], cfg["system"]["log_level"])

    # ---------- Licensing ----------
    licence = LicenceManager(licence_file=ROOT / "config" / "licence.json")
    logger.info("=" * 60)
    logger.info("SOVEREIGN QUANT BACKTEST ENGINE – UNIQUE INSTANCE")
    logger.info(f"Licence tier : {licence.info.tier.value.upper()} | Licensee: {licence.info.licensee}")
    logger.info("=" * 60)

    # Enforce capital limit from licence
    requested_cash = args.cash or cfg["capital"]["initial_cash"]
    max_cash = licence.max_capital()
    if requested_cash > max_cash:
        logger.warning(f"Requested capital {requested_cash:,.0f} exceeds licence limit {max_cash:,.0f}. Capping.")
        requested_cash = max_cash

    # Data
    loader = DataLoader(cfg["system"]["data_dir"])
    all_syms = cfg["data"]["symbols"]["equities"]
    prices = {}
    for sym in all_syms:
        try:
            prices[sym] = loader.load(
                sym,
                start=args.start or cfg["backtest"]["start_date"],
                end=args.end or cfg["backtest"].get("end_date"),
                timeframe="1d",
                source="yfinance",
            )
        except Exception as e:
            logger.warning(f"Skipping {sym}: {e}")
    if len(prices) < 2:
        logger.error("Insufficient price data loaded – aborting")
        sys.exit(1)
    logger.info(f"Successfully loaded {list(prices.keys())}")

    # Strategies – respect concurrent limit
    pairs_params = cfg["strategies"]["pairs"].copy()
    pairs_params["pairs"] = cfg["data"]["pairs"]
    momentum_params = cfg["strategies"]["momentum"].copy()
    momentum_params["symbols"] = list(prices.keys())
    mr_params = cfg["strategies"]["mean_reversion"].copy()
    mr_params["symbols"] = list(prices.keys())

    strategies = []
    max_strat = int(licence.info.features.get("max_strategies_concurrent", 1))
    if "pairs" in cfg["strategies"]["enabled"] and len(strategies) < max_strat:
        strategies.append(PairsStrategy(pairs_params))
    if "momentum" in cfg["strategies"]["enabled"] and len(strategies) < max_strat:
        strategies.append(MomentumStrategy(momentum_params))
    if "mean_reversion" in cfg["strategies"]["enabled"] and len(strategies) < max_strat:
        strategies.append(MeanReversionStrategy(mr_params))

    logger.info(f"Active strategies ({len(strategies)}/{max_strat}): {[s.name for s in strategies]}")

    # Risk
    risk_limits = RiskLimits(
        max_daily_loss_pct=cfg["risk"]["max_daily_loss_pct"],
        max_drawdown_pct=cfg["risk"]["max_drawdown_pct"],
        max_position_risk_pct=cfg["risk"]["max_position_risk_pct"],
        max_portfolio_heat=cfg["risk"]["max_portfolio_heat"],
        max_leverage=cfg["capital"]["max_leverage"],
        kill_switch_enabled=cfg["risk"]["kill_switch_enabled"],
    )

    engine = BacktestEngine(
        initial_cash=requested_cash,
        commission=cfg["backtest"]["commission"],
        slippage=cfg["backtest"]["slippage"],
        risk_limits=risk_limits,
    )

    result = engine.run(
        prices=prices,
        strategies=strategies,
        start=args.start or cfg["backtest"]["start_date"],
        end=args.end,
    )

    # Report
    print("\n" + "=" * 60)
    print("SOVEREIGN QUANT – BACKTEST RESULTS")
    print("=" * 60)
    for k, v in result.metrics.items():
        if isinstance(v, float):
            if "return" in k or "drawdown" in k or "cagr" in k or "volatility" in k:
                print(f"  {k:20s}: {v: .2%}")
            else:
                print(f"  {k:20s}: {v: .3f}")
        else:
            print(f"  {k:20s}: {v}")
    print("=" * 60)
    print(f"Licence  : {licence.info.tier.value.upper()} ({licence.info.licensee})")
    print(f"Risk status: {result.risk_status}")
    print(f"Total trades executed: {len(result.trades)}")
    print("=" * 60)

    # Save equity curve
    out_dir = ROOT / "logs"
    out_dir.mkdir(exist_ok=True)
    result.equity_curve.to_csv(out_dir / "equity_curve.csv")
    logger.info(f"Equity curve saved to {out_dir / 'equity_curve.csv'}")

    # Professional tearsheet (branded when licensed)
    reporter = TearsheetGenerator(
        licence_tier=licence.info.tier.value,
        licensee=licence.info.licensee,
    )
    html_path = reporter.generate(
        equity=result.equity_curve,
        metrics=result.metrics,
        trades=result.trades,
        risk_status=result.risk_status,
        output_dir=out_dir,
    )
    print(f"Tearsheet : {html_path}")

    if not result.equity_curve.empty:
        try:
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(12, 6))
            result.equity_curve.plot(ax=ax, title="Sovereign Quant Equity Curve", color="#00ff9f")
            ax.set_ylabel("Equity")
            ax.grid(True, alpha=0.3)
            fig.savefig(out_dir / "equity_curve.png", dpi=150, bbox_inches="tight")
            logger.info(f"Equity plot saved to {out_dir / 'equity_curve.png'}")
        except Exception as e:
            logger.warning(f"Could not plot: {e}")

    return result


if __name__ == "__main__":
    main()
