"""
Sovereign Quant Trading System
==============================
A complete, proprietary, turnkey quantitative trading platform.
Designed for sole ownership and operational excellence.
"""

__version__ = "1.0.0-unique"
__author__ = "Sovereign Quant Owner"

from .risk.manager import RiskManager
from .backtest.engine import BacktestEngine

__all__ = ["RiskManager", "BacktestEngine", "__version__"]
