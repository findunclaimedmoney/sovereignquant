"""
Sovereign Quant – Multi-Agent Orchestrator
==========================================
Central coordinator that routes goals to specialized agents
and assembles final results. Fully offline and under owner control.
"""

from __future__ import annotations

from typing import Any
from loguru import logger

from .base import BaseAgent, Message, MessageType, AgentState


class Orchestrator(BaseAgent):
    name = "orchestrator"

    def __init__(self):
        super().__init__()
        self.agents: dict[str, BaseAgent] = {}
        self.history: list[Message] = []
        self.on(MessageType.GOAL, self._handle_goal)

    def register(self, agent: BaseAgent) -> None:
        self.agents[agent.name] = agent
        logger.info(f"Orchestrator registered agent: {agent.name}")

    def describe(self) -> str:
        return "Central multi-agent orchestrator for Sovereign Quant"

    def _handle_goal(self, message: Message) -> Message:
        goal = message.payload.get("goal", "").lower()
        logger.info(f"[orchestrator] Received goal: {goal}")

        results = {}

        # Simple routing logic based on goal keywords
        if any(k in goal for k in ["data", "load", "fetch", "price"]):
            if "data" in self.agents:
                resp = self.agents["data"].handle(
                    Message(type=MessageType.DATA, sender=self.name, payload=message.payload)
                )
                if resp:
                    results["data"] = resp.payload

        if any(k in goal for k in ["strategy", "signal", "pairs", "momentum", "reversion"]):
            if "strategy" in self.agents:
                resp = self.agents["strategy"].handle(
                    Message(type=MessageType.SIGNAL, sender=self.name, payload=message.payload)
                )
                if resp:
                    results["strategy"] = resp.payload

        if any(k in goal for k in ["risk", "check", "limit", "drawdown"]):
            if "risk" in self.agents:
                resp = self.agents["risk"].handle(
                    Message(type=MessageType.RISK_CHECK, sender=self.name, payload=message.payload)
                )
                if resp:
                    results["risk"] = resp.payload

        if any(k in goal for k in ["backtest", "run", "simulate", "full"]):
            # Full pipeline
            for name in ["data", "strategy", "risk", "reporting"]:
                if name in self.agents:
                    msg_type = {
                        "data": MessageType.DATA,
                        "strategy": MessageType.SIGNAL,
                        "risk": MessageType.RISK_CHECK,
                        "reporting": MessageType.REPORT,
                    }[name]
                    resp = self.agents[name].handle(
                        Message(type=msg_type, sender=self.name, payload={**message.payload, **results})
                    )
                    if resp:
                        results[name] = resp.payload

        if any(k in goal for k in ["licence", "license", "key", "activate"]):
            if "licence" in self.agents:
                resp = self.agents["licence"].handle(
                    Message(type=MessageType.LICENCE, sender=self.name, payload=message.payload)
                )
                if resp:
                    results["licence"] = resp.payload

        if any(k in goal for k in ["report", "tearsheet", "performance"]):
            if "reporting" in self.agents:
                resp = self.agents["reporting"].handle(
                    Message(type=MessageType.REPORT, sender=self.name, payload={**message.payload, **results})
                )
                if resp:
                    results["reporting"] = resp.payload

        self.history.append(message)
        return Message(
            type=MessageType.RESULT,
            sender=self.name,
            payload={
                "goal": goal,
                "results": results,
                "agents_used": list(results.keys()),
                "status": "completed",
            },
            correlation_id=message.id,
        )

    def run_goal(self, goal: str, **kwargs) -> dict[str, Any]:
        """High-level entry point for the owner or Super Agent."""
        msg = Message(
            type=MessageType.GOAL,
            sender="owner",
            payload={"goal": goal, **kwargs},
        )
        result = self.handle(msg)
        return result.payload if result else {"status": "failed"}
