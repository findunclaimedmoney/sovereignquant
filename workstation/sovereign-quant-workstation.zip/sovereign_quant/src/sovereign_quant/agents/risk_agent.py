"""Risk Agent – enforces non-bypassable risk gates."""

from __future__ import annotations

from loguru import logger
from .base import BaseAgent, Message, MessageType


class RiskAgent(BaseAgent):
    name = "risk"

    def __init__(self, risk_manager=None):
        super().__init__()
        self.risk_manager = risk_manager
        self.on(MessageType.RISK_CHECK, self._handle_risk)

    def describe(self) -> str:
        return "Non-bypassable risk gates and kill-switch"

    def _handle_risk(self, message: Message) -> Message:
        logger.info("[risk] Performing risk checks")
        status = {"alive": True, "kill_reason": ""}
        if self.risk_manager is not None:
            status = self.risk_manager.status()
        return message.reply(
            sender=self.name,
            type=MessageType.RESULT,
            payload={"risk_status": status, "status": "checked"},
        )
