"""Licence Agent – manages offline key validation and feature gates."""

from __future__ import annotations

from loguru import logger
from .base import BaseAgent, Message, MessageType


class LicenceAgent(BaseAgent):
    name = "licence"

    def __init__(self, licence_manager=None):
        super().__init__()
        self.licence_manager = licence_manager
        self.on(MessageType.LICENCE, self._handle_licence)

    def describe(self) -> str:
        return "Offline licence validation and feature gating"

    def _handle_licence(self, message: Message) -> Message:
        action = message.payload.get("action", "status")
        logger.info(f"[licence] Action: {action}")
        status = {"tier": "community", "licensee": "Unauthenticated"}
        if self.licence_manager is not None:
            status = self.licence_manager.status()
        return message.reply(
            sender=self.name,
            type=MessageType.RESULT,
            payload={"licence": status, "status": "ok"},
        )
