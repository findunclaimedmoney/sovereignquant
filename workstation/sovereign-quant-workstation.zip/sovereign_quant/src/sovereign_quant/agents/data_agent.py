"""Data Agent – responsible for market data loading and caching."""

from __future__ import annotations

from typing import Any
from loguru import logger

from .base import BaseAgent, Message, MessageType


class DataAgent(BaseAgent):
    name = "data"

    def __init__(self, loader=None):
        super().__init__()
        self.loader = loader
        self.on(MessageType.DATA, self._handle_data)

    def describe(self) -> str:
        return "Loads and caches OHLCV data via yfinance / CCXT"

    def _handle_data(self, message: Message) -> Message:
        symbols = message.payload.get("symbols", ["QQQ", "IWM", "GLD", "TLT"])
        start = message.payload.get("start")
        end = message.payload.get("end")
        logger.info(f"[data] Loading symbols: {symbols}")

        prices = {}
        if self.loader is not None:
            for sym in symbols:
                try:
                    prices[sym] = self.loader.load(sym, start=start, end=end)
                except Exception as e:
                    logger.warning(f"[data] Failed {sym}: {e}")
        else:
            # Lightweight stub when loader not injected
            prices = {s: f"<DataFrame for {s}>" for s in symbols}

        return message.reply(
            sender=self.name,
            type=MessageType.RESULT,
            payload={"prices": list(prices.keys()), "count": len(prices), "status": "loaded"},
        )
