"""Strategy Agent – generates signals from the three core strategies."""

from __future__ import annotations

from loguru import logger
from .base import BaseAgent, Message, MessageType


class StrategyAgent(BaseAgent):
    name = "strategy"

    def __init__(self, strategies: list | None = None):
        super().__init__()
        self.strategies = strategies or []
        self.on(MessageType.SIGNAL, self._handle_signal)

    def describe(self) -> str:
        return "Runs pairs, momentum and mean-reversion strategies"

    def _handle_signal(self, message: Message) -> Message:
        logger.info(f"[strategy] Generating signals with {len(self.strategies)} strategies")
        # In full integration this would call strategy.generate_signals()
        return message.reply(
            sender=self.name,
            type=MessageType.RESULT,
            payload={
                "strategies_run": [getattr(s, "name", str(s)) for s in self.strategies] or ["pairs", "momentum", "mean_reversion"],
                "status": "signals_ready",
            },
        )
