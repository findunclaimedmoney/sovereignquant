"""
Sovereign Quant – Multi-Agent Base Classes
==========================================
Lightweight, offline-first agent framework.
All agents remain under the owner's sole control.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable
import uuid
from loguru import logger


class MessageType(str, Enum):
    GOAL = "goal"
    DATA = "data"
    SIGNAL = "signal"
    RISK_CHECK = "risk_check"
    ORDER = "order"
    REPORT = "report"
    LICENCE = "licence"
    STATUS = "status"
    ERROR = "error"
    RESULT = "result"


@dataclass
class Message:
    type: MessageType
    sender: str
    payload: dict[str, Any]
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    correlation_id: str | None = None

    def reply(self, sender: str, type: MessageType, payload: dict[str, Any]) -> "Message":
        return Message(
            type=type,
            sender=sender,
            payload=payload,
            correlation_id=self.id,
        )


class AgentState(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    WAITING = "waiting"
    ERROR = "error"
    DONE = "done"


class BaseAgent(ABC):
    """Abstract base for all Sovereign agents."""

    name: str = "base"

    def __init__(self):
        self.state = AgentState.IDLE
        self._handlers: dict[MessageType, Callable[[Message], Message | None]] = {}
        self._register_handlers()

    def _register_handlers(self) -> None:
        """Override to register message type handlers."""
        pass

    def on(self, msg_type: MessageType, handler: Callable[[Message], Message | None]) -> None:
        self._handlers[msg_type] = handler

    def handle(self, message: Message) -> Message | None:
        handler = self._handlers.get(message.type)
        if handler is None:
            logger.debug(f"[{self.name}] No handler for {message.type}")
            return None
        self.state = AgentState.RUNNING
        try:
            result = handler(message)
            self.state = AgentState.IDLE
            return result
        except Exception as e:
            self.state = AgentState.ERROR
            logger.error(f"[{self.name}] Error handling {message.type}: {e}")
            return Message(
                type=MessageType.ERROR,
                sender=self.name,
                payload={"error": str(e), "original": message.id},
                correlation_id=message.id,
            )

    @abstractmethod
    def describe(self) -> str:
        """Short description of agent capabilities."""
        ...
