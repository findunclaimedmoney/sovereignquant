"""Reporting Agent – produces professional tearsheets."""

from __future__ import annotations

from loguru import logger
from .base import BaseAgent, Message, MessageType


class ReportingAgent(BaseAgent):
    name = "reporting"

    def __init__(self, generator=None):
        super().__init__()
        self.generator = generator
        self.on(MessageType.REPORT, self._handle_report)

    def describe(self) -> str:
        return "Generates branded HTML performance tearsheets"

    def _handle_report(self, message: Message) -> Message:
        logger.info("[reporting] Building tearsheet")
        return message.reply(
            sender=self.name,
            type=MessageType.RESULT,
            payload={"report": "tearsheet_generated", "status": "ready"},
        )
