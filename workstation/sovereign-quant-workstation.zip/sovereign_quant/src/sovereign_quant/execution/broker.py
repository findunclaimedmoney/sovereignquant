"""
CCXT-based Broker Adapter for Paper & Live Trading
==================================================
Sandbox / demo mode is forced by default for safety.
"""

from __future__ import annotations

import os
from typing import Any
import ccxt
from loguru import logger
from dotenv import load_dotenv

load_dotenv()


class Broker:
    """Thin, safe wrapper around CCXT with mandatory sandbox until explicitly disabled."""

    def __init__(
        self,
        exchange_id: str = "binance",
        sandbox: bool = True,
        api_key: str | None = None,
        secret: str | None = None,
    ):
        self.exchange_id = exchange_id
        self.sandbox = sandbox
        self.api_key = api_key or os.getenv("API_KEY")
        self.secret = secret or os.getenv("API_SECRET")

        exchange_class = getattr(ccxt, exchange_id)
        config: dict[str, Any] = {
            "enableRateLimit": True,
            "options": {"defaultType": "future"},  # prefer USDT-M perps when available
        }
        if self.api_key and self.secret:
            config["apiKey"] = self.api_key
            config["secret"] = self.secret

        self.exchange = exchange_class(config)

        # Force sandbox / demo
        if sandbox:
            try:
                if hasattr(self.exchange, "set_sandbox_mode"):
                    self.exchange.set_sandbox_mode(True)
                if hasattr(self.exchange, "enable_demo_trading"):
                    self.exchange.enable_demo_trading(True)
                logger.warning("SANDBOX / DEMO MODE ACTIVE – no real capital at risk")
            except Exception as e:
                logger.warning(f"Could not force sandbox: {e}. Proceed with extreme caution.")

        self.exchange.load_markets()
        logger.info(f"Broker connected: {exchange_id} | sandbox={sandbox}")

    def fetch_balance(self) -> dict:
        return self.exchange.fetch_balance()

    def fetch_ticker(self, symbol: str) -> dict:
        return self.exchange.fetch_ticker(symbol)

    def create_order(
        self,
        symbol: str,
        side: str,
        amount: float,
        order_type: str = "market",
        price: float | None = None,
        params: dict | None = None,
    ) -> dict:
        params = params or {}
        if self.sandbox:
            params.setdefault("test", True)  # extra safety on some exchanges
        logger.info(f"ORDER {side.upper()} {amount} {symbol} @ {order_type} (sandbox={self.sandbox})")
        return self.exchange.create_order(symbol, order_type, side, amount, price, params)

    def cancel_all(self, symbol: str | None = None) -> list:
        if symbol:
            return self.exchange.cancel_all_orders(symbol)
        # fallback: cancel per market if supported
        return []

    def fetch_positions(self) -> list:
        if hasattr(self.exchange, "fetch_positions"):
            return self.exchange.fetch_positions()
        return []

    def is_sandbox(self) -> bool:
        return self.sandbox
