"""
Sovereign Quant – Professional Tearsheet / Report Generator
==========================================================
Produces high-quality HTML (and optional text) performance reports.
Branded reports are a Professional+ feature and form part of the monetisation layer.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import pandas as pd
from loguru import logger


class TearsheetGenerator:
    def __init__(self, licence_tier: str = "community", licensee: str = "User"):
        self.tier = licence_tier
        self.licensee = licensee
        self.branded = licence_tier in ("professional", "institutional")

    def generate(
        self,
        equity: pd.Series,
        metrics: dict[str, float],
        trades: list[Any],
        risk_status: dict[str, Any],
        output_dir: str | Path = "logs",
        title: str = "Sovereign Quant Performance Report",
    ) -> Path:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        html_path = output_dir / f"tearsheet_{timestamp}.html"

        # Basic metrics formatting
        def pct(v):
            try:
                return f"{float(v):.2%}"
            except Exception:
                return str(v)

        def num(v):
            try:
                return f"{float(v):,.2f}"
            except Exception:
                return str(v)

        rows = ""
        for k, v in metrics.items():
            if any(x in k.lower() for x in ("return", "drawdown", "cagr", "volatility")):
                display = pct(v)
            else:
                display = num(v) if isinstance(v, (int, float)) else str(v)
            rows += f"<tr><td>{k.replace('_', ' ').title()}</td><td style='text-align:right'>{display}</td></tr>\n"

        brand_header = ""
        if self.branded:
            brand_header = f"""
            <div style="background:#0a0a0a;color:#00ff9f;padding:12px 20px;font-family:monospace;font-size:14px;">
                SOVEREIGN QUANT &nbsp;|&nbsp; Licensed to: {self.licensee} &nbsp;|&nbsp; Tier: {self.tier.upper()}
            </div>
            """
        else:
            brand_header = """
            <div style="background:#333;color:#aaa;padding:8px 20px;font-family:sans-serif;font-size:12px;">
                Community Edition – Upgrade to Professional for branded institutional reports
            </div>
            """

        html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 0; background: #111; color: #eee; }}
.container {{ max-width: 960px; margin: 40px auto; padding: 0 20px; }}
h1 {{ color: #00ff9f; font-weight: 600; }}
table {{ width: 100%; border-collapse: collapse; margin: 24px 0; }}
th, td {{ padding: 10px 14px; border-bottom: 1px solid #333; }}
th {{ text-align: left; color: #00ff9f; }}
.metric-card {{ display: inline-block; background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 16px 24px; margin: 8px; min-width: 140px; }}
.metric-value {{ font-size: 1.6rem; font-weight: 700; color: #00ff9f; }}
.metric-label {{ font-size: 0.8rem; color: #888; text-transform: uppercase; }}
footer {{ margin-top: 48px; font-size: 0.75rem; color: #666; text-align: center; }}
</style>
</head>
<body>
{brand_header}
<div class="container">
<h1>{title}</h1>
<p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} UTC</p>

<div>
  <div class="metric-card"><div class="metric-value">{pct(metrics.get("total_return", 0))}</div><div class="metric-label">Total Return</div></div>
  <div class="metric-card"><div class="metric-value">{pct(metrics.get("cagr", 0))}</div><div class="metric-label">CAGR</div></div>
  <div class="metric-card"><div class="metric-value">{num(metrics.get("sharpe", 0))}</div><div class="metric-label">Sharpe</div></div>
  <div class="metric-card"><div class="metric-value">{pct(metrics.get("max_drawdown", 0))}</div><div class="metric-label">Max DD</div></div>
</div>

<h2>Full Metrics</h2>
<table>
<thead><tr><th>Metric</th><th>Value</th></tr></thead>
<tbody>
{rows}
</tbody>
</table>

<h2>Risk Snapshot</h2>
<pre style="background:#1a1a1a;padding:16px;border-radius:6px;overflow:auto;">{risk_status}</pre>

<h2>Trade Summary</h2>
<p>Total trades recorded: <strong>{len(trades)}</strong></p>

<footer>
Sovereign Quant Trading System &mdash; Proprietary software. All rights reserved.<br>
This report is for research and educational purposes only. Past performance is not indicative of future results.
</footer>
</div>
</body>
</html>
"""
        html_path.write_text(html, encoding="utf-8")
        logger.info(f"Tearsheet written to {html_path}")
        return html_path
