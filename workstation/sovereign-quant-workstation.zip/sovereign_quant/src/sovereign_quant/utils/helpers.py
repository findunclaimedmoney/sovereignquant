"""Utility helpers used across the Sovereign Quant system."""

from __future__ import annotations

import hashlib
from typing import Any
import numpy as np
import pandas as pd
from scipy import stats


def ensure_datetime_index(df: pd.DataFrame) -> pd.DataFrame:
    """Force a clean UTC datetime index."""
    if not isinstance(df.index, pd.DatetimeIndex):
        if "datetime" in df.columns:
            df = df.set_index("datetime")
        elif "date" in df.columns:
            df = df.set_index("date")
        else:
            raise ValueError("No datetime-like column found")
    df.index = pd.to_datetime(df.index, utc=True).tz_localize(None)
    return df.sort_index()


def annualise_vol(returns: pd.Series, periods: int = 252) -> float:
    return float(returns.std() * np.sqrt(periods))


def half_life(spread: pd.Series) -> float:
    """Ornstein-Uhlenbeck half-life estimation."""
    spread = spread.dropna()
    if len(spread) < 20:
        return np.nan
    lag = spread.shift(1).dropna()
    delta = spread.diff().dropna()
    lag = lag.loc[delta.index]
    beta = np.polyfit(lag, delta, 1)[0]
    if beta >= 0:
        return np.inf
    return float(-np.log(2) / beta)


def zscore(series: pd.Series, window: int) -> pd.Series:
    mean = series.rolling(window).mean()
    std = series.rolling(window).std()
    return (series - mean) / std


def rolling_ols_hedge(y: pd.Series, x: pd.Series, window: int) -> pd.Series:
    """Rolling OLS hedge ratio (beta of y on x)."""
    betas = []
    idx = []
    for i in range(window, len(y)):
        y_w = y.iloc[i - window : i]
        x_w = x.iloc[i - window : i]
        if y_w.isna().any() or x_w.isna().any():
            betas.append(np.nan)
        else:
            beta = np.polyfit(x_w, y_w, 1)[0]
            betas.append(beta)
        idx.append(y.index[i])
    return pd.Series(betas, index=idx)


def cointegration_pvalue(y: pd.Series, x: pd.Series) -> float:
    """Engle-Granger two-step residual ADF p-value."""
    from statsmodels.tsa.stattools import adfuller
    from statsmodels.regression.linear_model import OLS
    y, x = y.align(x, join="inner")
    if len(y) < 50:
        return 1.0
    model = OLS(y, x).fit()
    resid = model.resid
    adf = adfuller(resid, maxlag=1, regression="c")
    return float(adf[1])


def safe_div(a: float | np.ndarray, b: float | np.ndarray, default: float = 0.0) -> float | np.ndarray:
    with np.errstate(divide="ignore", invalid="ignore"):
        result = np.true_divide(a, b)
        if isinstance(result, np.ndarray):
            result[~np.isfinite(result)] = default
        elif not np.isfinite(result):
            result = default
    return result


def hash_config(cfg: dict[str, Any]) -> str:
    """Deterministic short hash of config for reproducibility stamps."""
    raw = str(sorted(cfg.items())).encode()
    return hashlib.sha256(raw).hexdigest()[:12]
