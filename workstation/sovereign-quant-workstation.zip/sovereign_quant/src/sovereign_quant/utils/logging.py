"""Centralised structured logging for Sovereign Quant."""

from __future__ import annotations

import sys
from pathlib import Path
from loguru import logger


def setup_logging(log_dir: str | Path = "logs", level: str = "INFO", rotation: str = "10 MB") -> None:
    """Configure loguru with console + rotating file sinks."""
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    logger.remove()
    logger.add(
        sys.stderr,
        level=level,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>",
        colorize=True,
    )
    logger.add(
        Path(log_dir) / "sovereign_quant_{time:YYYY-MM-DD}.log",
        level=level,
        rotation=rotation,
        retention="30 days",
        compression="zip",
        format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} - {message}",
    )
    logger.info("Sovereign Quant logging initialised")
