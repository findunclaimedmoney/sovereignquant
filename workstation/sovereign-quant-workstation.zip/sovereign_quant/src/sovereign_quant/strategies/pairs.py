"""
Statistical Arbitrage / Pairs Trading Strategy
==============================================
Engle-Granger cointegration + rolling OLS hedge + z-score mean reversion
with half-life filter and hard stops.
"""

from __future__ import annotations

from typing import Any
import numpy as np
import pandas as pd
from loguru import logger

from .base import Strategy, Signal
from ..utils.helpers import cointegration_pvalue, half_life, rolling_ols_hedge, zscore


class PairsStrategy(Strategy):
    name = "pairs"

    def __init__(self, params: dict[str, Any]):
        super().__init__(params)
        self.lookback = int(params.get("lookback", 60))
        self.entry_z = float(params.get("entry_z", 2.0))
        self.exit_z = float(params.get("exit_z", 0.5))
        self.stop_z = float(params.get("stop_z", 3.5))
        self.min_hl = float(params.get("min_half_life", 5))
        self.max_hl = float(params.get("max_half_life", 60))
        self.coint_p = float(params.get("cointegration_pvalue", 0.05))
        self.pairs: list[tuple[str, str]] = [
            tuple(p) for p in params.get("pairs", [["SPY", "QQQ"]])
        ]

    def required_symbols(self) -> list[str]:
        syms = set()
        for a, b in self.pairs:
            syms.add(a)
            syms.add(b)
        return list(syms)

    def generate_signals(self, prices: dict[str, pd.DataFrame]) -> pd.DataFrame:
        records = []
        for y_sym, x_sym in self.pairs:
            if y_sym not in prices or x_sym not in prices:
                logger.warning(f"Missing data for pair {y_sym}/{x_sym}")
                continue

            y = prices[y_sym]["close"].dropna()
            x = prices[x_sym]["close"].dropna()
            common = y.index.intersection(x.index)
            y = y.loc[common]
            x = x.loc[common]

            if len(y) < self.lookback + 50:
                continue

            # Static cointegration screen on full sample (research mode)
            pval = cointegration_pvalue(y, x)
            if pval > self.coint_p:
                logger.debug(f"Pair {y_sym}/{x_sym} not cointegrated (p={pval:.3f})")
                continue

            beta = rolling_ols_hedge(y, x, self.lookback)
            spread = y.loc[beta.index] - beta * x.loc[beta.index]
            z = zscore(spread, self.lookback)
            hl = half_life(spread)

            if not (self.min_hl <= hl <= self.max_hl):
                logger.debug(f"Half-life {hl:.1f} outside bounds for {y_sym}/{x_sym}")
                continue

            for ts, zv in z.items():
                if pd.isna(zv):
                    continue
                side = "flat"
                strength = 0.0
                stop = None
                if zv >= self.entry_z:
                    side = "short"  # short the spread (short y, long x)
                    strength = min(1.0, (zv - self.entry_z) / (self.stop_z - self.entry_z + 1e-9))
                    stop = abs(zv - self.stop_z) / max(abs(zv), 1e-9) * 0.05  # rough
                elif zv <= -self.entry_z:
                    side = "long"
                    strength = min(1.0, (-zv - self.entry_z) / (self.stop_z - self.entry_z + 1e-9))
                    stop = abs(zv + self.stop_z) / max(abs(zv), 1e-9) * 0.05
                elif abs(zv) <= self.exit_z:
                    side = "flat"
                    strength = 0.0

                # Emit two legs
                if side != "flat":
                    records.append(
                        {
                            "datetime": ts,
                            "symbol": y_sym,
                            "side": side,
                            "strength": strength,
                            "stop_pct": stop,
                            "pair": f"{y_sym}/{x_sym}",
                            "zscore": zv,
                            "beta": beta.loc[ts] if ts in beta.index else np.nan,
                            "strategy": self.name,
                        }
                    )
                    # Hedge leg opposite
                    hedge_side = "long" if side == "short" else "short"
                    records.append(
                        {
                            "datetime": ts,
                            "symbol": x_sym,
                            "side": hedge_side,
                            "strength": strength * abs(beta.loc[ts]) if ts in beta.index else strength,
                            "stop_pct": stop,
                            "pair": f"{y_sym}/{x_sym}",
                            "zscore": zv,
                            "beta": beta.loc[ts] if ts in beta.index else np.nan,
                            "strategy": self.name,
                        }
                    )

        if not records:
            return pd.DataFrame()
        df = pd.DataFrame(records)
        df = df.set_index("datetime").sort_index()
        return df
