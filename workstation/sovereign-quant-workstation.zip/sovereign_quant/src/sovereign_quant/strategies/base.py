"""Abstract strategy interface for Sovereign Quant."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any
import pandas as pd


@dataclass
class Signal:
    symbol: str
    side: str          # "long" | "short" | "flat"
    strength: float    # 0-1 conviction
    stop_pct: float | None = None
    meta: dict[str, Any] | None = None


class Strategy(ABC):
    """All strategies must implement generate_signals on a aligned price panel."""

    name: str = "base"

    def __init__(self, params: dict[str, Any]):
        self.params = params

    @abstractmethod
    def generate_signals(self, prices: dict[str, pd.DataFrame]) -> pd.DataFrame:
        """
        Returns a DataFrame indexed by datetime with columns:
        symbol, side, strength, stop_pct, ...
        or a multi-index / wide format that the engine understands.
        For simplicity we return a long-format DataFrame of signals.
        """
        ...

    def required_symbols(self) -> list[str]:
        return []
