"""
Momentum / Trend-Following with Volatility Targeting
====================================================
Dual moving-average + ADX filter + volatility-scaled position sizing.
"""

from __future__ import annotations

from typing import Any
import numpy as np
import pandas as pd
from loguru import logger

from .base import Strategy


def _true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    prev_close = close.shift(1)
    tr = pd.concat(
        [
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr


def _adx(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    tr = _true_range(high, low, close)
    up = high.diff()
    down = -low.diff()
    plus_dm = np.where((up > down) & (up > 0), up, 0.0)
    minus_dm = np.where((down > up) & (down > 0), down, 0.0)
    atr = tr.rolling(period).mean()
    plus_di = 100 * pd.Series(plus_dm, index=high.index).rolling(period).mean() / atr
    minus_di = 100 * pd.Series(minus_dm, index=high.index).rolling(period).mean() / atr
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-9)
    return dx.rolling(period).mean()


class MomentumStrategy(Strategy):
    name = "momentum"

    def __init__(self, params: dict[str, Any]):
        super().__init__(params)
        self.fast = int(params.get("fast_window", 20))
        self.slow = int(params.get("slow_window", 100))
        self.adx_period = int(params.get("adx_period", 14))
        self.adx_thresh = float(params.get("adx_threshold", 25))
        self.vol_target = float(params.get("vol_target", 0.15))
        self.vol_lookback = int(params.get("vol_lookback", 20))
        self.breakout = int(params.get("breakout_lookback", 55))
        self.symbols: list[str] = params.get("symbols", ["SPY", "QQQ", "BTC/USDT"])

    def required_symbols(self) -> list[str]:
        return self.symbols

    def generate_signals(self, prices: dict[str, pd.DataFrame]) -> pd.DataFrame:
        records = []
        for sym in self.symbols:
            if sym not in prices:
                continue
            df = prices[sym].copy()
            if len(df) < self.slow + 50:
                continue

            close = df["close"]
            high = df["high"]
            low = df["low"]

            fast_ma = close.rolling(self.fast).mean()
            slow_ma = close.rolling(self.slow).mean()
            adx = _adx(high, low, close, self.adx_period)
            ret = close.pct_change()
            vol = ret.rolling(self.vol_lookback).std() * np.sqrt(252)
            # Donchian-style breakout confirmation
            upper = high.rolling(self.breakout).max()
            lower = low.rolling(self.breakout).min()

            for ts in close.index[self.slow :]:
                if pd.isna(fast_ma.loc[ts]) or pd.isna(adx.loc[ts]) or pd.isna(vol.loc[ts]):
                    continue
                side = "flat"
                strength = 0.0
                stop = None

                trend_up = fast_ma.loc[ts] > slow_ma.loc[ts]
                trend_down = fast_ma.loc[ts] < slow_ma.loc[ts]
                strong = adx.loc[ts] >= self.adx_thresh
                breakout_up = close.loc[ts] >= upper.loc[ts] * 0.995
                breakout_dn = close.loc[ts] <= lower.loc[ts] * 1.005

                if trend_up and strong and breakout_up:
                    side = "long"
                    # vol targeting strength proxy
                    strength = min(1.0, self.vol_target / max(vol.loc[ts], 0.05))
                    stop = 2.0 * vol.loc[ts] / np.sqrt(252)  # ~2 daily vol
                elif trend_down and strong and breakout_dn:
                    side = "short"
                    strength = min(1.0, self.vol_target / max(vol.loc[ts], 0.05))
                    stop = 2.0 * vol.loc[ts] / np.sqrt(252)

                if side != "flat":
                    records.append(
                        {
                            "datetime": ts,
                            "symbol": sym,
                            "side": side,
                            "strength": strength,
                            "stop_pct": stop,
                            "adx": adx.loc[ts],
                            "vol": vol.loc[ts],
                            "strategy": self.name,
                        }
                    )

        if not records:
            return pd.DataFrame()
        return pd.DataFrame(records).set_index("datetime").sort_index()
