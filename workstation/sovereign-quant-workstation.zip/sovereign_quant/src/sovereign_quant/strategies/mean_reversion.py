"""
Market-Neutral Mean-Reversion Strategy
======================================
Z-score of price vs rolling mean with low-volatility regime filter.
Can be applied single-asset or residual after market beta.
"""

from __future__ import annotations

from typing import Any
import numpy as np
import pandas as pd
from loguru import logger

from .base import Strategy
from ..utils.helpers import zscore


class MeanReversionStrategy(Strategy):
    name = "mean_reversion"

    def __init__(self, params: dict[str, Any]):
        super().__init__(params)
        self.window = int(params.get("window", 20))
        self.entry_z = float(params.get("entry_z", 2.0))
        self.exit_z = float(params.get("exit_z", 0.3))
        self.regime_filter = bool(params.get("regime_filter", True))
        self.low_vol_pct = float(params.get("low_vol_percentile", 40))
        self.symbols: list[str] = params.get("symbols", ["SPY", "QQQ", "IWM"])

    def required_symbols(self) -> list[str]:
        return self.symbols

    def generate_signals(self, prices: dict[str, pd.DataFrame]) -> pd.DataFrame:
        records = []
        for sym in self.symbols:
            if sym not in prices:
                continue
            close = prices[sym]["close"].dropna()
            if len(close) < self.window + 50:
                continue

            z = zscore(close, self.window)
            ret = close.pct_change()
            vol = ret.rolling(self.window).std()
            vol_rank = vol.rolling(252, min_periods=60).apply(
                lambda x: pd.Series(x).rank(pct=True).iloc[-1], raw=False
            )

            for ts in close.index[self.window :]:
                if pd.isna(z.loc[ts]):
                    continue
                if self.regime_filter and (pd.isna(vol_rank.loc[ts]) or vol_rank.loc[ts] > self.low_vol_pct / 100):
                    continue  # only trade in relatively quiet regimes

                side = "flat"
                strength = 0.0
                stop = None
                zv = z.loc[ts]

                if zv >= self.entry_z:
                    side = "short"
                    strength = min(1.0, (zv - self.entry_z) / 2.0)
                    stop = 0.03
                elif zv <= -self.entry_z:
                    side = "long"
                    strength = min(1.0, (-zv - self.entry_z) / 2.0)
                    stop = 0.03
                elif abs(zv) <= self.exit_z:
                    side = "flat"

                if side != "flat":
                    records.append(
                        {
                            "datetime": ts,
                            "symbol": sym,
                            "side": side,
                            "strength": strength,
                            "stop_pct": stop,
                            "zscore": zv,
                            "strategy": self.name,
                        }
                    )

        if not records:
            return pd.DataFrame()
        return pd.DataFrame(records).set_index("datetime").sort_index()
