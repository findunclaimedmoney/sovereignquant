"""
Sovereign Quant – Licensing & Feature Gate System
=================================================
Offline, cryptographically signed licence keys.
Enables clean software-licensing revenue without touching client funds or live order routing.

Tiers
-----
Community   : Free – limited capital, basic reports, single strategy at a time
Professional: Paid – full strategies, higher capital, walk-forward, branded reports
Institutional: Paid – all features + Monte-Carlo, multi-account simulation, priority support flag

Owner generates keys with the included keygen utility.
Keys are validated locally; no phone-home required.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import platform
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from enum import Enum
from pathlib import Path
from typing import Any
from loguru import logger


class LicenceTier(str, Enum):
    COMMUNITY = "community"
    PROFESSIONAL = "professional"
    INSTITUTIONAL = "institutional"


# Feature matrix – single source of truth for what each tier unlocks
TIER_FEATURES: dict[LicenceTier, dict[str, Any]] = {
    LicenceTier.COMMUNITY: {
        "max_initial_capital": 50_000,
        "max_strategies_concurrent": 1,
        "walk_forward": False,
        "monte_carlo": False,
        "branded_reports": False,
        "export_pdf": False,
        "advanced_risk_analytics": False,
        "signal_export": False,
        "multi_account": False,
    },
    LicenceTier.PROFESSIONAL: {
        "max_initial_capital": 1_000_000,
        "max_strategies_concurrent": 3,
        "walk_forward": True,
        "monte_carlo": False,
        "branded_reports": True,
        "export_pdf": True,
        "advanced_risk_analytics": True,
        "signal_export": True,
        "multi_account": False,
    },
    LicenceTier.INSTITUTIONAL: {
        "max_initial_capital": 50_000_000,
        "max_strategies_concurrent": 10,
        "walk_forward": True,
        "monte_carlo": True,
        "branded_reports": True,
        "export_pdf": True,
        "advanced_risk_analytics": True,
        "signal_export": True,
        "multi_account": True,
    },
}


@dataclass
class LicenceInfo:
    tier: LicenceTier
    licensee: str
    issued: str
    expires: str | None          # ISO date or None for perpetual
    features: dict[str, Any]
    machine_id: str | None = None
    key_id: str | None = None

    def is_expired(self) -> bool:
        if self.expires is None:
            return False
        try:
            exp = datetime.fromisoformat(self.expires).replace(tzinfo=timezone.utc)
            return datetime.now(timezone.utc) > exp
        except Exception:
            return True

    def to_dict(self) -> dict:
        d = asdict(self)
        d["tier"] = self.tier.value
        return d


class LicenceManager:
    """
    Handles validation, feature checks and local licence storage.
    The secret used for signing must be kept private by the software owner.
    """

    def __init__(self, secret: str | None = None, licence_file: str | Path = "config/licence.json"):
        # Owner should replace this with a long random secret before distributing
        self.secret = (secret or os.getenv("SOVEREIGN_LICENCE_SECRET") or "CHANGE-ME-TO-A-LONG-RANDOM-SECRET-BEFORE-DISTRIBUTION").encode()
        self.licence_file = Path(licence_file)
        self._info: LicenceInfo | None = None
        self._load()

    @staticmethod
    def machine_fingerprint() -> str:
        """Simple offline machine identifier (not perfect, but raises the bar)."""
        raw = f"{platform.node()}|{platform.system()}|{platform.machine()}|{platform.processor()}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def _sign(self, payload: str) -> str:
        return hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()

    def _verify_signature(self, payload: str, signature: str) -> bool:
        expected = self._sign(payload)
        return hmac.compare_digest(expected, signature)

    def generate_key(
        self,
        licensee: str,
        tier: LicenceTier,
        days_valid: int | None = 365,
        bind_machine: bool = False,
    ) -> str:
        """
        Owner-only method. Generate a signed licence key string.
        Run this from a private script; never ship the generator with the product.
        """
        issued = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        expires = None
        if days_valid is not None:
            expires = (datetime.now(timezone.utc) + timedelta(days=days_valid)).strftime("%Y-%m-%d")

        machine = self.machine_fingerprint() if bind_machine else None
        key_id = hashlib.sha256(f"{licensee}{issued}{tier.value}".encode()).hexdigest()[:10]

        data = {
            "licensee": licensee,
            "tier": tier.value,
            "issued": issued,
            "expires": expires,
            "machine_id": machine,
            "key_id": key_id,
        }
        payload = json.dumps(data, sort_keys=True, separators=(",", ":"))
        signature = self._sign(payload)
        token = f"{payload}|{signature}"
        import base64
        return base64.urlsafe_b64encode(token.encode()).decode().rstrip("=")

    def activate(self, key: str) -> LicenceInfo:
        """Validate and store a licence key supplied by the user."""
        import base64
        try:
            padded = key + "=" * (-len(key) % 4)
            token = base64.urlsafe_b64decode(padded).decode()
            payload, signature = token.rsplit("|", 1)
        except Exception as e:
            raise ValueError(f"Malformed licence key: {e}") from e

        if not self._verify_signature(payload, signature):
            raise ValueError("Invalid licence signature – key is not authentic")

        data = json.loads(payload)
        tier = LicenceTier(data["tier"])
        info = LicenceInfo(
            tier=tier,
            licensee=data["licensee"],
            issued=data["issued"],
            expires=data.get("expires"),
            features=TIER_FEATURES[tier].copy(),
            machine_id=data.get("machine_id"),
            key_id=data.get("key_id"),
        )

        if info.is_expired():
            raise ValueError("Licence has expired")

        if info.machine_id and info.machine_id != self.machine_fingerprint():
            raise ValueError("Licence is bound to a different machine")

        self.licence_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.licence_file, "w") as f:
            json.dump({"key": key, "info": info.to_dict()}, f, indent=2)

        self._info = info
        logger.info(f"Licence activated: {info.tier.value.upper()} for {info.licensee}")
        return info

    def _load(self) -> None:
        if not self.licence_file.exists():
            self._info = LicenceInfo(
                tier=LicenceTier.COMMUNITY,
                licensee="Unauthenticated",
                issued=datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                expires=None,
                features=TIER_FEATURES[LicenceTier.COMMUNITY].copy(),
            )
            return
        try:
            with open(self.licence_file) as f:
                stored = json.load(f)
            self.activate(stored["key"])
        except Exception as e:
            logger.warning(f"Could not load licence ({e}) – falling back to Community tier")
            self._info = LicenceInfo(
                tier=LicenceTier.COMMUNITY,
                licensee="Unauthenticated",
                issued=datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                expires=None,
                features=TIER_FEATURES[LicenceTier.COMMUNITY].copy(),
            )

    @property
    def info(self) -> LicenceInfo:
        assert self._info is not None
        return self._info

    def has_feature(self, feature: str) -> bool:
        return bool(self.info.features.get(feature, False))

    def max_capital(self) -> float:
        return float(self.info.features.get("max_initial_capital", 50_000))

    def require(self, feature: str, message: str | None = None) -> None:
        if not self.has_feature(feature):
            msg = message or f"Feature '{feature}' requires a higher licence tier (current: {self.info.tier.value})"
            raise PermissionError(msg)

    def status(self) -> dict[str, Any]:
        return {
            "tier": self.info.tier.value,
            "licensee": self.info.licensee,
            "issued": self.info.issued,
            "expires": self.info.expires,
            "expired": self.info.is_expired(),
            "features": self.info.features,
        }
