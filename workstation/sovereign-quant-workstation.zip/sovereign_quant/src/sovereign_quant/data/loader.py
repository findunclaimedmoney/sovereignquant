"""Robust multi-source market data loader for Sovereign Quant."""

from __future__ import annotations

from pathlib import Path
from typing import Literal
import pandas as pd
import yfinance as yf
import ccxt
from loguru import logger

from ..utils.helpers import ensure_datetime_index


class DataLoader:
    """Unified OHLCV loader with caching and source fallback."""

    def __init__(self, cache_dir: str | Path = "data/cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._ccxt_exchanges: dict[str, ccxt.Exchange] = {}

    def _cache_path(self, symbol: str, timeframe: str, source: str) -> Path:
        safe = symbol.replace("/", "_").replace(":", "_")
        return self.cache_dir / f"{source}_{safe}_{timeframe}.parquet"

    def load(
        self,
        symbol: str,
        start: str | None = None,
        end: str | None = None,
        timeframe: str = "1d",
        source: Literal["yfinance", "ccxt"] = "yfinance",
        exchange_id: str = "binance",
        force_refresh: bool = False,
    ) -> pd.DataFrame:
        """Load OHLCV. Returns clean DataFrame with columns open, high, low, close, volume."""
        cache = self._cache_path(symbol, timeframe, source)
        if cache.exists() and not force_refresh:
            df = pd.read_parquet(cache)
            df = ensure_datetime_index(df)
            if start:
                df = df[df.index >= pd.Timestamp(start)]
            if end:
                df = df[df.index <= pd.Timestamp(end)]
            if not df.empty:
                logger.debug(f"Cache hit: {symbol} ({source})")
                return df

        if source == "yfinance":
            df = self._load_yfinance(symbol, start, end, timeframe)
        else:
            df = self._load_ccxt(symbol, start, end, timeframe, exchange_id)

        if df.empty:
            raise ValueError(f"No data returned for {symbol} via {source}")

        df = ensure_datetime_index(df)
        df = df[["open", "high", "low", "close", "volume"]].astype(float)
        df = df[~df.index.duplicated(keep="last")].sort_index()
        df.to_parquet(cache)
        logger.info(f"Loaded & cached {symbol}: {len(df)} bars ({source})")
        return df

    def _load_yfinance(self, symbol: str, start: str | None, end: str | None, timeframe: str) -> pd.DataFrame:
        interval_map = {"1d": "1d", "1h": "1h", "4h": "1h", "15m": "15m"}
        interval = interval_map.get(timeframe, "1d")
        ticker = yf.Ticker(symbol)
        df = ticker.history(start=start, end=end, interval=interval, auto_adjust=True)
        if df.empty:
            return df
        df = df.rename(columns=str.lower)
        df = df[["open", "high", "low", "close", "volume"]]
        return df

    def _load_ccxt(
        self,
        symbol: str,
        start: str | None,
        end: str | None,
        timeframe: str,
        exchange_id: str,
    ) -> pd.DataFrame:
        if exchange_id not in self._ccxt_exchanges:
            exchange_class = getattr(ccxt, exchange_id)
            self._ccxt_exchanges[exchange_id] = exchange_class({"enableRateLimit": True})
        exchange = self._ccxt_exchanges[exchange_id]

        since = None
        if start:
            since = int(pd.Timestamp(start).timestamp() * 1000)

        all_ohlcv = []
        limit = 1000
        while True:
            ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=limit)
            if not ohlcv:
                break
            all_ohlcv.extend(ohlcv)
            if len(ohlcv) < limit:
                break
            since = ohlcv[-1][0] + 1
            if end and since > int(pd.Timestamp(end).timestamp() * 1000):
                break

        if not all_ohlcv:
            return pd.DataFrame()

        df = pd.DataFrame(all_ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms")
        df = df.set_index("datetime").drop(columns=["timestamp"])
        if end:
            df = df[df.index <= pd.Timestamp(end)]
        return df

    def load_multiple(
        self,
        symbols: list[str],
        start: str | None = None,
        end: str | None = None,
        timeframe: str = "1d",
        source: str = "yfinance",
    ) -> dict[str, pd.DataFrame]:
        result = {}
        for sym in symbols:
            try:
                result[sym] = self.load(sym, start, end, timeframe, source=source)  # type: ignore
            except Exception as e:
                logger.warning(f"Failed to load {sym}: {e}")
        return result
