"""
Sovereign Risk Manager
======================
Non-bypassable, deterministic risk gates.
Every order must pass through check_order().
Kill switch and daily loss limits are enforced at the portfolio level.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any
import numpy as np
from loguru import logger


@dataclass
class RiskLimits:
    max_daily_loss_pct: float = 0.02
    max_drawdown_pct: float = 0.12
    max_position_risk_pct: float = 0.01
    max_portfolio_heat: float = 0.06
    max_correlation: float = 0.75
    max_leverage: float = 2.0
    kill_switch_enabled: bool = True


@dataclass
class PortfolioState:
    equity: float
    cash: float
    positions: dict[str, float] = field(default_factory=dict)  # symbol -> notional
    peak_equity: float = 0.0
    daily_start_equity: float = 0.0
    current_day: date | None = None
    killed: bool = False
    kill_reason: str = ""


class RiskManager:
    """Hard risk gate. Cannot be disabled or soft-bypassed."""

    def __init__(self, limits: RiskLimits | None = None):
        self.limits = limits or RiskLimits()
        self.state = PortfolioState(equity=0.0, cash=0.0, peak_equity=0.0, daily_start_equity=0.0)
        self._trade_log: list[dict[str, Any]] = []

    def reset(self, initial_equity: float) -> None:
        self.state = PortfolioState(
            equity=initial_equity,
            cash=initial_equity,
            peak_equity=initial_equity,
            daily_start_equity=initial_equity,
            current_day=None,
            killed=False,
            kill_reason="",
        )
        self._trade_log.clear()
        logger.info(f"RiskManager reset with equity={initial_equity:,.2f}")

    def update_equity(self, equity: float, current_date: date | None = None) -> None:
        self.state.equity = equity
        self.state.peak_equity = max(self.state.peak_equity, equity)

        if current_date is not None:
            if self.state.current_day is None or current_date != self.state.current_day:
                self.state.daily_start_equity = equity
                self.state.current_day = current_date

        # Drawdown kill
        dd = (self.state.peak_equity - equity) / self.state.peak_equity if self.state.peak_equity > 0 else 0
        if dd >= self.limits.max_drawdown_pct and self.limits.kill_switch_enabled:
            self._trigger_kill(f"Max drawdown breached: {dd:.2%} >= {self.limits.max_drawdown_pct:.2%}")

        # Daily loss kill
        if self.state.daily_start_equity > 0:
            daily_loss = (self.state.daily_start_equity - equity) / self.state.daily_start_equity
            if daily_loss >= self.limits.max_daily_loss_pct and self.limits.kill_switch_enabled:
                self._trigger_kill(f"Daily loss limit: {daily_loss:.2%} >= {self.limits.max_daily_loss_pct:.2%}")

    def _trigger_kill(self, reason: str) -> None:
        if not self.state.killed:
            self.state.killed = True
            self.state.kill_reason = reason
            logger.critical(f"KILL SWITCH ACTIVATED: {reason}")

    def check_order(
        self,
        symbol: str,
        side: str,
        notional: float,
        stop_distance_pct: float | None = None,
        current_positions: dict[str, float] | None = None,
    ) -> tuple[bool, str, float]:
        """
        Returns (allowed, reason, adjusted_notional).
        adjusted_notional may be reduced to satisfy heat limits.
        """
        if self.state.killed:
            return False, f"System killed: {self.state.kill_reason}", 0.0

        if notional <= 0:
            return False, "Notional must be positive", 0.0

        equity = self.state.equity
        if equity <= 0:
            return False, "Zero or negative equity", 0.0

        # Leverage check
        total_exposure = sum(abs(v) for v in (current_positions or self.state.positions).values()) + notional
        leverage = total_exposure / equity
        if leverage > self.limits.max_leverage:
            return False, f"Leverage {leverage:.2f}x exceeds {self.limits.max_leverage}x", 0.0

        # Position risk (using stop distance if provided)
        risk_pct = self.limits.max_position_risk_pct
        if stop_distance_pct and stop_distance_pct > 0:
            max_notional_by_risk = (equity * risk_pct) / stop_distance_pct
            if notional > max_notional_by_risk:
                notional = max_notional_by_risk
                logger.debug(f"Size reduced by stop-risk to {notional:.2f}")

        # Portfolio heat
        current_heat = sum(
            abs(v) * risk_pct for v in (current_positions or self.state.positions).values()
        ) / equity if equity else 0
        additional_heat = (notional * risk_pct) / equity
        if current_heat + additional_heat > self.limits.max_portfolio_heat:
            remaining_heat = max(0.0, self.limits.max_portfolio_heat - current_heat)
            notional = (remaining_heat * equity) / risk_pct
            if notional <= 0:
                return False, "Portfolio heat limit reached", 0.0
            logger.debug(f"Size reduced by heat limit to {notional:.2f}")

        return True, "OK", float(notional)

    def record_fill(self, symbol: str, side: str, notional: float, price: float) -> None:
        sign = 1.0 if side.lower() == "buy" else -1.0
        self.state.positions[symbol] = self.state.positions.get(symbol, 0.0) + sign * notional
        self._trade_log.append(
            {
                "symbol": symbol,
                "side": side,
                "notional": notional,
                "price": price,
                "equity": self.state.equity,
            }
        )

    def is_alive(self) -> bool:
        return not self.state.killed

    def status(self) -> dict[str, Any]:
        dd = (self.state.peak_equity - self.state.equity) / self.state.peak_equity if self.state.peak_equity else 0
        return {
            "equity": self.state.equity,
            "peak": self.state.peak_equity,
            "drawdown": dd,
            "killed": self.state.killed,
            "kill_reason": self.state.kill_reason,
            "positions": dict(self.state.positions),
        }
